#ifndef __PS2_KEYBOARD
#define __PS2_KEYBOARD
	
	extern	int	read_PS2_data_ASM(char * data);

#endif