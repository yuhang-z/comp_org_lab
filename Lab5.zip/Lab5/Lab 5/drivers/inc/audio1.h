#ifndef __AUDIO
#define __AUDIO

	extern int write_audio_ASM(int data_written);

#endif