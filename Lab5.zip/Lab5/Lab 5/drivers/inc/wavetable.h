#ifndef __WAVETABLE
#define __WAVETABLE

extern int sine[48000];

#endif
